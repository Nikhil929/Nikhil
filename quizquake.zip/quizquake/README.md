# QuizQuake: BrainStorm Arena

Adaptive CS quiz with a weak-topic radar chart.

- Frontend: React + TypeScript + Chart.js (Vite)
- Backend: Node + Express (TypeScript)

## Run
```
npm run install:all
npm run dev
```
Open http://localhost:5173

## How the adaptive logic works
See `client/src/engine.ts`. Start at Medium. Two correct in a row go up one tier, one wrong goes down one tier,
and the streak resets after each change. Subtopics are picked round-robin so a 10-question quiz covers everything.
Timer and progress are saved to sessionStorage so a refresh won't lose the session; history lives in localStorage.
