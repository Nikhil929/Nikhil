export type Tier = 'Easy' | 'Medium' | 'Hard';
export interface Question { id: number; topic: string; sub: string; tier: Tier; q: string; options: string[]; answer: number; why: string }
export interface Answer { id: number; chosen: number | null; ms: number }
export interface SubStat { sub: string; topic: string; correct: number; total: number; pct: number }
export interface Report { score: number; total: number; stats: SubStat[] }
export interface Attempt { date: string; score: number; total: number; topic: string }
