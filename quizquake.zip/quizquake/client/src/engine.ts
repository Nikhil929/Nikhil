import type { Question, Tier } from './types';

const TIERS: Tier[] = ['Easy', 'Medium', 'Hard'];

export interface EngineState { tier: Tier; streak: number }

// Two correct answers in a row move you up one tier; a single miss drops you one tier.
// The streak resets after every tier change, which stops the tier from bouncing around.
export function nextState(s: EngineState, correct: boolean): EngineState {
  const i = TIERS.indexOf(s.tier);
  if (!correct) return { tier: TIERS[Math.max(0, i - 1)], streak: 0 };
  if (s.streak + 1 >= 2 && i < 2) return { tier: TIERS[i + 1], streak: 0 };
  return { tier: s.tier, streak: s.streak + 1 };
}

// Round-robin over subtopics: always pick from the least-asked subtopic, then the closest available tier.
export function pickQuestion(pool: Question[], askedIds: number[], tier: Tier): Question | null {
  const fresh = pool.filter(q => !askedIds.includes(q.id));
  if (!fresh.length) return null;
  const count = (sub: string) => pool.filter(q => q.sub === sub && askedIds.includes(q.id)).length;
  const subs = [...new Set(fresh.map(q => q.sub))];
  const least = Math.min(...subs.map(count));
  const options = subs.filter(s => count(s) === least);
  const sub = options[Math.floor(Math.random() * options.length)];
  const want = TIERS.indexOf(tier);
  const inSub = fresh.filter(q => q.sub === sub);
  inSub.sort((a, b) => Math.abs(TIERS.indexOf(a.tier) - want) - Math.abs(TIERS.indexOf(b.tier) - want));
  return inSub[0];
}
