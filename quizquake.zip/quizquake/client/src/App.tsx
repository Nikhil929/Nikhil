import { useEffect, useRef, useState } from 'react';
import { Chart, registerables } from 'chart.js';
import { nextState, pickQuestion } from './engine';
import type { Answer, Attempt, Question, Report, Tier } from './types';

Chart.register(...registerables);

const QUIZ_LEN = 10;
const QUIZ_SECS = 600;
const SESSION_KEY = 'quizquake-session';
const HISTORY_KEY = 'quizquake-history';
const WEAK_BELOW = 60;

interface Session { topic: string; asked: number[]; answers: Answer[]; tier: Tier; streak: number; endAt: number; qStart: number; total: number }
interface Result { r: Report; answers: Answer[]; topic: string }

const loadHistory = (): Attempt[] => {
  try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]'); } catch { return []; }
};
const saveAttempt = (a: Attempt) => localStorage.setItem(HISTORY_KEY, JSON.stringify([...loadHistory(), a]));
const mmss = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;

function ChartBox({ kind, labels, data, label }: { kind: 'radar' | 'line'; labels: string[]; data: number[]; label: string }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const scale = { min: 0, max: 100 };
    const chart = new Chart(ref.current!, {
      type: kind,
      data: { labels, datasets: [{ label, data, borderColor: '#4f46e5', backgroundColor: 'rgba(79,70,229,.25)', fill: kind === 'radar', tension: 0.3 }] },
      options: { scales: kind === 'radar' ? { r: scale } : { y: scale } },
    } as any);
    return () => chart.destroy();
  }, [labels.join('|'), data.join('|')]);
  return <canvas ref={ref} />;
}

export default function App() {
  const [bank, setBank] = useState<Question[]>([]);
  const [sess, setSess] = useState<Session | null>(null);
  const [result, setResult] = useState<Result | null>(null);
  const [picked, setPicked] = useState<number | null>(null);
  const [left, setLeft] = useState(QUIZ_SECS);
  const [topic, setTopic] = useState('All');
  const [err, setErr] = useState('');
  const finishing = useRef(false);

  useEffect(() => {
    fetch('/api/questions').then(r => r.json()).then(setBank).catch(() => setErr('Cannot reach the API. Is the server running?'));
    const saved = sessionStorage.getItem(SESSION_KEY); // resume after a refresh
    if (saved) setSess(JSON.parse(saved));
  }, []);

  useEffect(() => { if (sess) sessionStorage.setItem(SESSION_KEY, JSON.stringify(sess)); }, [sess]);

  useEffect(() => {
    if (!sess) return;
    const tick = () => {
      const s = Math.max(0, Math.round((sess.endAt - Date.now()) / 1000));
      setLeft(s);
      if (s === 0) finish(sess, true);
    };
    tick();
    const t = setInterval(tick, 500);
    return () => clearInterval(t);
  }, [sess]);

  const poolFor = (t: string) => bank.filter(q => t === 'All' || q.topic === t);

  function start() {
    const pool = poolFor(topic);
    const first = pickQuestion(pool, [], 'Medium');
    if (!first) return;
    finishing.current = false;
    setResult(null);
    setPicked(null);
    setSess({ topic, asked: [first.id], answers: [], tier: 'Medium', streak: 0, endAt: Date.now() + QUIZ_SECS * 1000, qStart: Date.now(), total: Math.min(QUIZ_LEN, pool.length) });
  }

  function next() {
    if (!sess || picked === null) return;
    const q = bank.find(b => b.id === sess.asked[sess.asked.length - 1])!;
    const answers = [...sess.answers, { id: q.id, chosen: picked, ms: Date.now() - sess.qStart }];
    setPicked(null);
    const st = nextState({ tier: sess.tier, streak: sess.streak }, picked === q.answer);
    const nq = answers.length < sess.total ? pickQuestion(poolFor(sess.topic), sess.asked, st.tier) : null;
    if (!nq) return void finish({ ...sess, answers });
    setSess({ ...sess, answers, asked: [...sess.asked, nq.id], tier: st.tier, streak: st.streak, qStart: Date.now() });
  }

  async function finish(s: Session, timedOut = false) {
    if (finishing.current) return;
    finishing.current = true;
    let answers = s.answers;
    if (timedOut && answers.length < s.asked.length) answers = [...answers, { id: s.asked[answers.length], chosen: null, ms: Date.now() - s.qStart }];
    try {
      const res = await fetch('/api/diagnose', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ answers }) });
      const r: Report = await res.json();
      saveAttempt({ date: new Date().toISOString(), score: r.score, total: r.total, topic: s.topic });
      sessionStorage.removeItem(SESSION_KEY);
      setSess(null);
      setResult({ r, answers, topic: s.topic });
    } catch {
      setErr('Could not submit. Check the server and refresh.');
      finishing.current = false;
    }
  }

  if (err) return <main><div className="card">{err}</div></main>;
  if (!bank.length) return <main>Loading…</main>;

  if (sess) {
    const q = bank.find(b => b.id === sess.asked[sess.asked.length - 1])!;
    return (
      <main>
        <div className="top">
          <span>Question {sess.answers.length + 1} of {sess.total}</span>
          <span className={'timer' + (left < 60 ? ' low' : '')}>⏱ {mmss(left)}</span>
        </div>
        <div className="bar"><div style={{ width: `${(sess.answers.length / sess.total) * 100}%` }} /></div>
        <div className="card">
          <div className="top"><small>{q.topic} · {q.sub}</small><span className={'badge ' + q.tier}>{q.tier}</span></div>
          <h3>{q.q}</h3>
          {q.options.map((o, i) => (
            <button key={i} className={picked === i ? 'sel' : ''} onClick={() => setPicked(i)}>{o}</button>
          ))}
          <button className="primary" disabled={picked === null} onClick={next}>
            {sess.answers.length + 1 === sess.total ? 'Finish' : 'Next'}
          </button>
        </div>
      </main>
    );
  }

  if (result) {
    const { r, answers } = result;
    const weak = r.stats.filter(s => s.pct < WEAK_BELOW);
    const history = loadHistory();
    return (
      <main>
        <h1>Score: {r.score}/{r.total}</h1>
        <div className="card">
          <h3>Mastery by subtopic</h3>
          <ChartBox kind="radar" labels={r.stats.map(s => s.sub)} data={r.stats.map(s => s.pct)} label="Mastery %" />
          {weak.length ? <p>Weak spots: {weak.map(w => <span className="weak" key={w.sub}>{w.sub} ({w.pct}%) </span>)}</p> : <p className="ok">No weak spots found. Nice.</p>}
        </div>
        <div className="card">
          <h3>Your history</h3>
          <ChartBox kind="line" labels={history.map((_, i) => `#${i + 1}`)} data={history.map(h => Math.round((h.score / h.total) * 100))} label="Score %" />
        </div>
        <h2>Review</h2>
        {answers.map((a, i) => {
          const q = bank.find(b => b.id === a.id)!;
          const right = a.chosen === q.answer;
          return (
            <div className="card" key={a.id}>
              <div className="top"><small>Q{i + 1} · {q.sub}</small><span className={'badge ' + q.tier}>{q.tier}</span></div>
              <p><b>{q.q}</b></p>
              <p className={right ? 'ok' : 'no'}>You: {a.chosen === null ? 'No answer' : q.options[a.chosen]}</p>
              {!right && <p className="ok">Correct: {q.options[q.answer]}</p>}
              <p>{q.why}</p>
              <small>Time spent: {(a.ms / 1000).toFixed(1)}s</small>
            </div>
          );
        })}
        <button className="primary" onClick={() => setResult(null)}>Back to start</button>
      </main>
    );
  }

  const topics = ['All', ...new Set(bank.map(b => b.topic))];
  const history = loadHistory();
  return (
    <main>
      <h1>QuizQuake ⚡</h1>
      <p>An adaptive quiz that gets harder as you get things right, then shows where you're weak.</p>
      <div className="card">
        <label>Topic</label>
        <select value={topic} onChange={e => setTopic(e.target.value)}>{topics.map(t => <option key={t}>{t}</option>)}</select>
        <button className="primary" onClick={start}>Start quiz</button>
        <small>{QUIZ_LEN} questions · {QUIZ_SECS / 60} minutes · starts at Medium</small>
      </div>
      {history.length > 0 && (
        <div className="card">
          <h3>Past attempts</h3>
          <ChartBox kind="line" labels={history.map((_, i) => `#${i + 1}`)} data={history.map(h => Math.round((h.score / h.total) * 100))} label="Score %" />
        </div>
      )}
    </main>
  );
}
