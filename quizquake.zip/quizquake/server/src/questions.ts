export type Tier = 'Easy' | 'Medium' | 'Hard';
export interface Question { id: number; topic: string; sub: string; tier: Tier; q: string; options: string[]; answer: number; why: string }

// topic, subtopic, tier, stem, options (first one is correct), explanation
type Row = [string, string, Tier, string, string[], string];
const rows: Row[] = [
['Data Structures','Arrays & Linked Lists','Easy','Time to read the i-th array element by index?',['O(1)','O(n)','O(log n)','O(n²)'],'Arrays sit in contiguous memory, so the address is base + i × size.'],
['Data Structures','Arrays & Linked Lists','Medium','How do you find the middle of a singly linked list in one pass?',['Slow and fast pointers','Reverse the list','Hash every node','Binary search'],'The fast pointer moves 2 nodes per step, so the slow one is at the middle when it ends.'],
['Data Structures','Arrays & Linked Lists','Hard',"Why must Floyd's cycle detection pointers meet inside a cycle?",['Fast gains one node per step on slow','They move at equal speed','Slow skips nodes','The cycle length is even'],'Inside a loop the gap shrinks by 1 each step, so it must hit zero.'],
['Data Structures','Stacks & Queues','Easy','Which structure is LIFO?',['Stack','Queue','Graph','Heap'],'A stack pops the most recently pushed item first.'],
['Data Structures','Stacks & Queues','Medium','Infix to postfix conversion keeps operators on a...',['Stack','Queue','Heap','Hash table'],'Operators wait on a stack until precedence rules say to pop them.'],
['Data Structures','Stacks & Queues','Hard','Fewest stacks needed for a queue with amortized O(1) dequeue?',['2','1','3','4'],'Push to an inbox stack; when the outbox is empty, move everything over.'],
['Data Structures','Trees & Graphs','Easy','Inorder traversal of a BST visits keys in what order?',['Ascending','Descending','Level by level','Random'],'Left, node, right gives sorted order by the BST property.'],
['Data Structures','Trees & Graphs','Medium','BFS uses which structure?',['Queue','Stack','Heap','Trie'],'A FIFO queue explores nodes in order of distance from the start.'],
['Data Structures','Trees & Graphs','Hard','Dijkstra with a binary heap runs in...',['O((V+E) log V)','O(V·E)','O(V³)','O(E + V)'],'Each edge relaxation may cost a heap update of O(log V).'],
['Algorithms','Sorting','Easy','Worst-case time of bubble sort?',['O(n²)','O(n log n)','O(n)','O(log n)'],'Nested passes compare roughly n²/2 pairs.'],
['Algorithms','Sorting','Medium','Which sort is stable and O(n log n) in the worst case?',['Merge sort','Quick sort','Heap sort','Selection sort'],'Merge sort keeps equal items in order and always splits evenly.'],
['Algorithms','Sorting','Hard','Lower bound for comparison-based sorting?',['Ω(n log n)','Ω(n)','Ω(n²)','Ω(log n)'],'A decision tree needs n! leaves, so its height is at least log(n!) ≈ n log n.'],
['Algorithms','Dynamic Programming','Easy','DP applies when a problem has overlapping subproblems and...',['Optimal substructure','No recursion','Sorted input','A graph form'],'Both properties let you reuse stored sub-answers.'],
['Algorithms','Dynamic Programming','Medium','Time of the classic 0/1 knapsack DP (n items, capacity W)?',['O(nW)','O(2ⁿ)','O(n log W)','O(W)'],'The table has n × W cells, each filled in constant time.'],
['Algorithms','Dynamic Programming','Hard','Extra space for LCS if you only need its length (lengths m, n)?',['O(min(m,n))','O(m·n)','O(1)','O(m·n·log n)'],'Each row depends only on the previous one, so two short rows are enough.'],
['Algorithms','Complexity','Easy',"Big-O describes a function's...",['Upper bound','Exact value','Lower bound','Average only'],'Big-O is an asymptotic upper bound.'],
['Algorithms','Complexity','Medium','Binary search on a sorted array takes...',['O(log n)','O(n)','O(n log n)','O(1)'],'Each step halves the search range.'],
['Algorithms','Complexity','Hard','T(n) = 2T(n/2) + n solves to...',['Θ(n log n)','Θ(n)','Θ(n²)','Θ(log n)'],'Master theorem case 2: log n levels, n work per level.'],
['Operating Systems','Scheduling','Easy','FCFS serves processes in order of...',['Arrival','Burst length','Priority','Memory size'],'First come, first served, by arrival time.'],
['Operating Systems','Scheduling','Medium','Which algorithm gives the minimum average waiting time (non-preemptive)?',['SJF','FCFS','Round robin','Priority'],'Running shortest jobs first is provably optimal for average wait.'],
['Operating Systems','Scheduling','Hard','Round robin with a huge time quantum behaves like...',['FCFS','SJF','SRTF','LIFO'],'No process is ever preempted, so they run in arrival order.'],
['Operating Systems','Deadlocks','Easy','Which is NOT a necessary condition for deadlock?',['Preemption','Mutual exclusion','Hold and wait','Circular wait'],'No preemption is required for deadlock, so preemption itself is not.'],
['Operating Systems','Deadlocks','Medium',"The Banker's algorithm is used for deadlock...",['Avoidance','Detection only','Ignoring','Killing processes'],'It grants a request only if the system stays in a safe state.'],
['Operating Systems','Deadlocks','Hard','A system is in a safe state if...',['Some order lets every process finish','No process is waiting','All resources are free','No process holds a lock'],'A safe sequence guarantees each process can get its maximum need and finish.'],
['Operating Systems','Memory Management','Easy','Paging eliminates which fragmentation?',['External','Internal','Both','Neither'],'Fixed-size frames remove external fragmentation; the last page may waste space.'],
['Operating Systems','Memory Management','Medium','A TLB caches...',['Recent page-table translations','Disk blocks','Process lists','Interrupts'],'It avoids a page-table memory lookup on every access.'],
['Operating Systems','Memory Management','Hard',"Belady's anomaly can occur under which policy?",['FIFO','LRU','Optimal','Any stack algorithm'],'FIFO is not a stack algorithm, so more frames can mean more faults.'],
['Networks','TCP/IP','Easy','Which protocol gives reliable, ordered delivery?',['TCP','UDP','ICMP','ARP'],'TCP uses sequence numbers, ACKs and retransmission.'],
['Networks','TCP/IP','Medium','TCP connection setup is called...',['Three-way handshake','Two-way ping','Four-way close','DNS lookup'],'SYN, SYN-ACK, ACK.'],
['Networks','TCP/IP','Hard','During slow start, cwnd grows...',['Exponentially per RTT','Linearly per RTT','Stays constant','Randomly'],'It roughly doubles each round trip until ssthresh.'],
['Networks','Routing','Easy','A router forwards packets based on...',['Destination IP','Source MAC only','Port number','Hostname'],'It matches the destination IP against its routing table.'],
['Networks','Routing','Medium','Which of these is a distance-vector protocol?',['RIP','OSPF','IS-IS','STP'],'RIP shares hop-count distances with neighbours.'],
['Networks','Routing','Hard','OSPF computes routes using...',['Dijkstra on a link-state map','Bellman-Ford','Prim','Kruskal'],'Every router floods link states and runs shortest-path first locally.'],
['Networks','Application Layer','Easy','DNS translates...',['Domain names to IP addresses','IPs to MACs','MACs to ports','URLs to files'],'It is the internet phonebook.'],
['Networks','Application Layer','Medium','Default HTTPS port?',['443','80','22','8080'],'HTTP is 80; HTTPS is 443.'],
['Networks','Application Layer','Hard','HTTP/2 multiplexing mainly fixes which HTTP/1.1 problem?',['Application-layer head-of-line blocking','DNS lookup cost','Lack of TLS','Cookie size'],'Many streams share one connection, so a slow response no longer blocks others (TCP-level blocking remains).'],
];

// Options are rotated by id so the right answer isn't always A, and a page refresh keeps the same order.
export const bank: Question[] = rows.map(([topic, sub, tier, q, opts, why], i) => {
  const id = i + 1, rot = id % 4;
  return { id, topic, sub, tier, q, why, options: opts.map((_, k) => opts[(k + rot) % 4]), answer: (4 - rot) % 4 };
});
