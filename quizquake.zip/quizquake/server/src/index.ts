import express from 'express';
import cors from 'cors';
import { bank } from './questions';

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/questions', (_req, res) => res.json(bank));

interface Submitted { id: number; chosen: number | null; ms: number }

// Turns raw answers into per-subtopic mastery.
app.post('/api/diagnose', (req, res) => {
  const answers: Submitted[] = req.body?.answers ?? [];
  const map = new Map<string, { sub: string; topic: string; correct: number; total: number }>();
  let score = 0;
  for (const a of answers) {
    const q = bank.find(b => b.id === a.id);
    if (!q) continue;
    const s = map.get(q.sub) ?? { sub: q.sub, topic: q.topic, correct: 0, total: 0 };
    s.total++;
    if (a.chosen === q.answer) { s.correct++; score++; }
    map.set(q.sub, s);
  }
  const stats = [...map.values()].map(s => ({ ...s, pct: Math.round((s.correct / s.total) * 100) }));
  res.json({ score, total: answers.length, stats });
});

const port = 4000;
app.listen(port, () => console.log(`API on http://localhost:${port}`));
